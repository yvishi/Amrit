rm *.h
